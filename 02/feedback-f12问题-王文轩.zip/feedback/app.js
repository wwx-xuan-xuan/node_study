var http = require('http');
var fs = require('fs');

var template = require('art-template')

var url = require('url')

var comments = [
  {
    name:"wwx",
    message:"wdfasf3wdsv",
    dataTime:'2016-11-11'
  },
  {
    name:"wwx2",
    message:"wdfasf3wdsv",
    dataTime:'2016-11-11'
  },
  {
    name:"wwx2",
    message:"wdfasf3wdsv",
    dataTime:'2016-11-11'
  },
  {
    name:"wwx3",
    message:"wdfasf3wdsv",
    dataTime:'2016-11-11'
  },
]

http
  .createServer(function (req, res) {

    // var url = req.url;
    var pathObj = url.parse(req.url, true)

    var pathname = pathObj.pathname
    console.log(pathname)

    if (pathname === '/') {
      fs.readFile('./views/留言本.html', function (err, data) {
        if (err) {
          return console.log('404 not found')
        }

        var ret = template.render(data.toString(), {
          comments:comments
        })

        res.end(ret)
        // res.end(data)
      })
    } else if (pathname === '/post') {

      fs.readFile('./views/post.html', function (err, data) {
        if (err) {
          return console.log('404 not foun dddd')

        }

        res.end(data)

      })
    } else if (pathname === '/pinglun') {
      console.log(pathObj.query)

      var json_str = JSON.stringify(pathObj.query)
      console.log(json_str)

      var json_par = JSON.parse(json_str)
      console.log(json_par)

    } else if (pathname.indexOf('/public/') === 0) {
      // console.log(url)
      fs.readFile('.' + pathname, function (err, data) {
        if (err) {
          return console.log(err)

        }

        res.end(data)

      })
    } else {
      fs.readFile('./views/404.html', function (err, data) {
        if (err) {
          return res.end('404 Not Found');
        }

        res.end(data)
      })
    }


  })

  .listen(3000, function () {
    console.log('running...')
  })